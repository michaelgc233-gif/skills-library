# Flink 异常解析器使用示例

## 核心规范要求

### 输出规范
1. **一句话输出**：只输出一句话，不出现任何技术术语
2. **内容要素**：
   - 错误核心原因
   - 受影响字段或问题关键词（如果可提取）
   - 简单明确的可执行建议
3. **语言风格**：业务化、直白、面向普通业务用户
4. **角色禁止**：禁止出现"管理员"、"支持团队"、"工程师"、"开发/DevOps"等角色名称

### 脱敏规范
1. **IP地址**：脱敏为"前两段 + *.*"的格式，保留端口信息
   - 示例：`172.30.34.3:6122` → `172.30.*.*:6122`
2. **主机名**：保留前部，其余用 * 替代
   - 示例：`host-prod-123` → `host-***`
3. **用户名**：保留首字符 + ***
   - 示例：`admin` → `a***`
4. **密码/密钥**：全部用 *** 替代
5. **业务字段**：表名、字段名不脱敏

### 错误分类处理
1. **服务中断类**（外部环境中断、服务停止、资源不可用）
   - 输出应使用"请重新发布任务"
   - 说明可能原因（如服务暂时不可用）
   - 使用"服务"而不是"服务器"

2. **数据问题类**（字段缺失、格式错误、配置错误）
   - 输出应使用"请修复后重新发布任务"
   - 说明如何修复

3. **中文异常直接返回**
   - 如果输入已经是中文并且能明确表达错误原因和可执行建议
   - 不再处理直接输出原文

## 示例测试用例

### 示例 1：字段缺失导致失败
**输入异常**：
```
Batch entry 6 INSERT INTO ... ERROR: null value in column "bigint_field" violates not-null constraint ...
```

**预期输出**：
```
任务同步失败，字段"bigint_field"缺少数据导致无法保存，请补齐该字段后重新发布任务。
```

### 示例 2：格式错误导致失败
**输入异常**：
```
date/time field value out of range: "2025-13-01"
```

**预期输出**：
```
任务同步失败，由于日期字段格式不正确导致无法处理，请修正日期格式后重新发布任务。
```

### 示例 3：服务中断导致停止
**输入异常**：
```
错误:host 172.30.34.3:6122 failed unexpectedly
```

**预期输出**：
```
任务发布中断，承载任务的服务 172.30.*.*:6122 可能不可用，请确认其恢复正常后重新发布任务。
```

### 示例 4：已是中文异常
**输入异常**：
```
字段"id"不能为空，请检查后重新发布任务。
```

**预期输出**：
```
字段"id"不能为空，请检查后重新发布任务。
```

### 示例 5：数据长度异常
**输入异常**：
```
value too long for type character varying(255)
```

**预期输出**：
```
任务同步失败，字段内容过长超出限制，请缩短内容后重新发布任务。
```

### 示例 6：唯一约束异常
**输入异常**：
```
duplicate key value violates unique constraint "users_email_key"
```

**预期输出**：
```
任务同步失败，存在重复数据导致无法保存，请检查并修正后重新发布任务。
```

### 示例 7：连接拒绝
**输入异常**：
```
Connection refused: connect to host 10.0.0.1:5432
```

**预期输出**：
```
任务发布中断，承载任务的服务 10.0.*.*:5432 可能不可用，请确认其恢复正常后重新发布任务。
```

### 示例 8：数据类型错误
**输入异常**：
```
invalid input syntax for type integer: "abc"
```

**预期输出**：
```
任务同步失败，字段数据类型不正确，请修正后重新发布任务。
```

### 示例 9：中文字段缺失
**输入异常**：
```
Column'创建人姓名'cannotbenull
```

**预期输出**：
```
任务同步失败，字段"创建人姓名"缺少数据导致无法保存，请补齐该字段后重新发布任务。
```

### 示例 10：包含敏感信息
**输入异常**：
```
Failed to connect to database at jdbc:postgresql://192.168.1.100:5432/mydb?user=admin&password=secret123
```

**预期输出**：
```
任务发布中断，承载任务的服务 192.168.*.*:5432 可能不可用，请确认其恢复正常后重新发布任务。
```

## 使用方式

### 命令行使用
```bash
# 直接传递异常信息
python scripts/flink_error_parser.py "Batch entry 6 INSERT INTO ... ERROR: null value in column 'bigint_field' violates not-null constraint"

# 从文件读取
cat error.log | python scripts/flink_error_parser.py

# 在Python代码中使用
from scripts.flink_error_parser import FlinkErrorParser

parser = FlinkErrorParser()
result = parser.parse("异常信息")
print(result)
```

### 集成到SaaS平台
```python
from scripts.flink_error_parser import FlinkErrorParser

class TaskErrorHandler:
    def __init__(self):
        self.parser = FlinkErrorParser()

    def handle_error(self, error_message, task_id):
        """处理任务错误，生成用户友好的提示"""
        user_friendly_message = self.parser.parse(error_message)

        # 记录到数据库
        self.log_error(task_id, error_message, user_friendly_message)

        # 发送到消息中心
        self.send_to_message_center(task_id, user_friendly_message)

        return user_friendly_message
```

## 错误处理模式

### 模式识别
解析器会自动识别以下模式：
1. **空值/缺失字段**：`null value`, `cannot be null`, `不能为空`
2. **格式错误**：`out of range`, `无效格式`, `格式不正确`
3. **服务中断**：`failed`, `中断`, `不可用`, `拒绝连接`
4. **长度限制**：`too long`, `超出限制`
5. **数据类型**：`invalid input syntax`, `类型不匹配`
6. **唯一约束**：`duplicate key`, `重复数据`

### 字段提取
解析器会尝试从异常信息中提取字段名，支持：
- 英文字段名：`column "field_name"`
- 中文字段名：`字段"字段名"`
- 无引号字段：`Column field_name`

### 脱敏处理
自动脱敏以下敏感信息：
1. IP地址：保留前两段
2. 主机名：保留前缀
3. 用户名：保留首字母
4. 密码/密钥：完全隐藏
5. 连接字符串：脱敏敏感部分

## 扩展建议

### 添加自定义模式
```python
class CustomFlinkErrorParser(FlinkErrorParser):
    def __init__(self):
        super().__init__()

        # 添加自定义模式
        self.patterns['custom_error'] = [
            r'自定义错误模式: ([^"\']+)',
            r'Custom error: ([^"\']+)'
        ]

    def generate_human_readable_message(self, error_text):
        # 先调用父类处理
        result = super().generate_human_readable_message(error_text)

        # 自定义处理逻辑
        if '自定义错误' in error_text:
            return "任务处理失败，请检查自定义配置后重新发布任务。"

        return result
```

### 多语言支持
可以通过扩展支持多语言错误消息：
```python
class MultilingualFlinkErrorParser(FlinkErrorParser):
    def __init__(self, language='zh'):
        super().__init__()
        self.language = language

        # 不同语言的消息模板
        self.message_templates = {
            'zh': {
                'null_value': "任务同步失败，字段'{field}'缺少数据导致无法保存，请补齐该字段后重新发布任务。",
                # ... 其他中文模板
            },
            'en': {
                'null_value': "Task synchronization failed, field '{field}' is missing data and cannot be saved. Please fill in this field and republish the task.",
                # ... 其他英文模板
            }
        }
```

## 测试验证

### 单元测试
建议为以下场景编写单元测试：
1. 各种异常模式的正确解析
2. 脱敏功能验证
3. 中文异常直接返回
4. 边界情况处理
5. 性能测试（大量异常处理）

### 集成测试
在SaaS平台环境中测试：
1. 真实异常日志处理
2. 并发处理能力
3. 内存使用情况
4. 错误恢复机制