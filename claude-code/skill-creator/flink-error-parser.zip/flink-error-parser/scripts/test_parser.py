#!/usr/bin/env python3
"""
Flink 异常解析器测试脚本

用于测试和验证 flink_error_parser.py 的功能
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from flink_error_parser import FlinkErrorParser


def run_tests():
    """运行测试用例"""
    parser = FlinkErrorParser()

    test_cases = [
        # (输入异常, 期望输出, 测试描述)
        (
            'Batch entry 6 INSERT INTO ... ERROR: null value in column "bigint_field" violates not-null constraint ...',
            "任务同步失败，字段'bigint_field'缺少数据导致无法保存，请补齐该字段后重新发布任务。",
            '字段缺失异常'
        ),
        (
            'date/time field value out of range: "2025-13-01"',
            "任务同步失败，由于日期字段格式不正确导致无法处理，请修正格式后重新发布任务。",
            '日期格式错误'
        ),
        (
            '错误:host 172.30.34.3:6122 failed unexpectedly',
            '任务发布中断，承载任务的服务 172.30.*.*:6122 可能不可用，请确认其恢复正常后重新发布任务。',
            '服务中断（IP脱敏）'
        ),
        (
            '字段"id"不能为空，请检查后重新发布任务。',
            '字段"id"不能为空，请检查后重新发布任务。',
            '中文异常直接返回'
        ),
        (
            'value too long for type character varying(255)',
            "任务同步失败，字段'内容'过长超出限制，请缩短内容后重新发布任务。",
            '数据长度异常'
        ),
        (
            'duplicate key value violates unique constraint "users_email_key"',
            "任务同步失败，字段'数据'存在重复导致无法保存，请检查并修正后重新发布任务。",
            '唯一约束异常'
        ),
        (
            'Connection refused: connect to host 10.0.0.1:5432',
            '任务发布中断，承载任务的服务 10.0.*.*:5432 可能不可用，请确认其恢复正常后重新发布任务。',
            '连接拒绝'
        ),
        (
            'invalid input syntax for type integer: "abc"',
            "任务同步失败，字段'数据'类型不正确，请修正后重新发布任务。",
            '数据类型错误'
        ),
        (
            "Column'创建人姓名'cannotbenull",
            "任务同步失败，字段'创建人姓名'缺少数据导致无法保存，请补齐该字段后重新发布任务。",
            '中文字段缺失'
        ),
        (
            'Failed to connect to database at jdbc:postgresql://192.168.1.100:5432/mydb?user=admin&password=secret123',
            '任务发布中断，承载任务的服务 192.168.*.*:5432 可能不可用，请确认其恢复正常后重新发布任务。',
            '包含敏感信息脱敏'
        ),
        (
            'host-prod-123 failed to respond',
            '任务发布中断，承载任务的服务 host-prod-*** 可能不可用，请确认其恢复正常后重新发布任务。',
            '主机名脱敏'
        ),
        (
            'User admin authentication failed',
            '任务发布中断，承载任务的服务可能暂时不可用，请确认其恢复正常后重新发布任务。',
            '用户名脱敏'
        ),
        (
            '未知错误类型',
            '任务同步失败，数据存在问题导致无法处理，请修复后重新发布任务。',
            '未知错误类型'
        ),
        (
            '',
            '未提供异常信息',
            '空输入'
        )
    ]

    print("=" * 80)
    print("Flink 异常解析器测试")
    print("=" * 80)

    passed = 0
    failed = 0

    for i, (input_text, expected_output, description) in enumerate(test_cases, 1):
        print(f"\n测试 {i}: {description}")
        print(f"输入: {input_text[:100]}{'...' if len(input_text) > 100 else ''}")

        try:
            actual_output = parser.parse(input_text)
            print(f"期望: {expected_output}")
            print(f"实际: {actual_output}")

            if actual_output == expected_output:
                print("✅ 通过")
                passed += 1
            else:
                print("❌ 失败")
                failed += 1
                print(f"差异: 期望 '{expected_output}'，实际 '{actual_output}'")

        except Exception as e:
            print(f"❌ 异常: {str(e)}")
            failed += 1

    print("\n" + "=" * 80)
    print(f"测试结果: 通过 {passed}/{len(test_cases)}，失败 {failed}/{len(test_cases)}")
    print("=" * 80)

    return failed == 0


def test_desensitization():
    """测试脱敏功能"""
    parser = FlinkErrorParser()

    test_cases = [
        ('172.30.34.3:6122', '172.30.*.*:6122', 'IP地址脱敏'),
        ('host-prod-database-123', 'host-***', '主机名脱敏'),
        ('admin_user', 'a***', '用户名脱敏'),
        ('password=secret123', 'password=***', '密码脱敏'),
        ('key=abc123def', 'key=***', '密钥脱敏'),
        ('正常字段名', '正常字段名', '业务字段不脱敏'),
    ]

    print("\n" + "=" * 80)
    print("脱敏功能测试")
    print("=" * 80)

    for input_text, expected, description in test_cases:
        actual = parser.desensitize(input_text)
        status = "✅" if actual == expected else "❌"
        print(f"{status} {description}: '{input_text}' -> '{actual}' (期望: '{expected}')")


def test_error_classification():
    """测试错误分类"""
    parser = FlinkErrorParser()

    test_cases = [
        ('null value in column "test"', ('null_value', 'test'), '空值异常'),
        ('date/time field value out of range', ('format_error', None), '格式错误'),
        ('host failed unexpectedly', ('service_interruption', None), '服务中断'),
        ('value too long', ('length_error', None), '长度异常'),
        ('invalid input syntax', ('type_error', None), '类型错误'),
        ('duplicate key', ('unique_constraint', None), '唯一约束'),
        ('unknown error', ('unknown', None), '未知错误'),
    ]

    print("\n" + "=" * 80)
    print("错误分类测试")
    print("=" * 80)

    for input_text, expected, description in test_cases:
        actual = parser.classify_error_type(input_text)
        status = "✅" if actual == expected else "❌"
        print(f"{status} {description}: {actual} (期望: {expected})")


def interactive_test():
    """交互式测试"""
    parser = FlinkErrorParser()

    print("\n" + "=" * 80)
    print("交互式测试模式")
    print("输入 'quit' 或 'exit' 退出")
    print("=" * 80)

    while True:
        try:
            user_input = input("\n请输入异常信息: ").strip()

            if user_input.lower() in ['quit', 'exit', 'q']:
                break

            if not user_input:
                print("请输入异常信息")
                continue

            result = parser.parse(user_input)
            print(f"\n解析结果: {result}")

            # 显示详细信息
            print("\n详细信息:")
            print(f"脱敏后: {parser.desensitize(user_input)}")
            print(f"是否中文异常: {parser.is_already_chinese_error(user_input)}")
            error_type, field = parser.classify_error_type(user_input)
            print(f"错误类型: {error_type}")
            print(f"提取字段: {field}")

        except KeyboardInterrupt:
            print("\n\n测试结束")
            break
        except Exception as e:
            print(f"错误: {str(e)}")


if __name__ == "__main__":
    import argparse

    arg_parser = argparse.ArgumentParser(description='Flink 异常解析器测试')
    arg_parser.add_argument('--mode', choices=['all', 'basic', 'desensitize', 'classification', 'interactive'],
                          default='all', help='测试模式')
    arg_parser.add_argument('--error', type=str, help='直接测试特定异常信息')

    args = arg_parser.parse_args()

    if args.error:
        # 直接测试特定异常
        parser = FlinkErrorParser()
        result = parser.parse(args.error)
        print(f"输入: {args.error}")
        print(f"输出: {result}")
        sys.exit(0)

    if args.mode in ['all', 'basic']:
        if not run_tests():
            sys.exit(1)

    if args.mode in ['all', 'desensitize']:
        test_desensitization()

    if args.mode in ['all', 'classification']:
        test_error_classification()

    if args.mode == 'interactive':
        interactive_test()

    print("\n测试完成！")