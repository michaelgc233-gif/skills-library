#!/usr/bin/env python3
"""
Flink 异常信息解析器

将来自 Flink 任务执行过程中的技术堆栈异常信息转换成直观简洁的白话提示，
适合展示在 SaaS 平台消息栏。

规范要求：
1）只输出一句话，不出现任何技术术语
2）文本应该描述：错误核心原因、受影响字段或问题关键词、简单明确的可执行建议
3）语言必须是业务化、直白且面向普通业务用户
4）对敏感信息进行合理脱敏处理
5）禁止在输出中出现管理员、支持团队、工程师等角色名称
6）如果输入已经是中文并且能明确表达错误原因和可执行建议，则不再处理直接输出原文
7）当异常提示表明任务是由于外部环境中断、服务停止或资源不可用导致停止时：
   - 输出应使用"请重新发布任务"
   - 并说明可能原因（如服务暂时不可用）与下一步操作
   - 请使用"服务"而不是"服务器"等字眼
8）当异常提示表明失败是由数据问题、字段缺失、格式错误或配置错误等：
   - 输出应使用"请修复后重新发布任务"
   - 并说明如何修复
"""

import re
from typing import Optional, Tuple, List


class FlinkErrorParser:
    def __init__(self):
        # 常见异常模式匹配
        self.patterns = {
            # 字段缺失/空值异常
            'null_value': [
                r'null value in column ["\']?([^"\'\s,]+)["\']? violates not-null',
                r'Column[\'"]?([^"\'\s,]+)[\'"]? cannot be null',
                r'Column[\'"]?([^"\'\s,]+)[\'"]?cannotbenull',
                r'column[\'"]?([^"\'\s,]+)[\'"]?cannotbenull',
                r'字段["\']?([^"\'\s,]+)["\']?不能为空',
                r'字段["\']?([^"\'\s,]+)["\']?缺少数据'
            ],
            # 格式错误异常
            'format_error': [
                r'date/time field value out of range: ["\']?([^"\'\s,]+)["\']?',
                r'无效的日期格式: ["\']?([^"\'\s,]+)["\']?',
                r'格式不正确: ["\']?([^"\'\s,]+)["\']?',
                r'格式错误: ["\']?([^"\'\s,]+)["\']?'
            ],
            # 服务中断异常
            'service_interruption': [
                r'host ([\d\.]+:\d+) failed',
                r'连接失败: ([\d\.]+:\d+)',
                r'服务不可用: ([\d\.]+:\d+)',
                r'connection refused',
                r'Failed to connect',
                r'无法连接'
            ],
            # 数据长度异常
            'length_error': [
                r'value too long for type',
                r'字符串长度超过限制',
                r'超出最大长度'
            ],
            # 数据类型异常
            'type_error': [
                r'invalid input syntax for type',
                r'数据类型不匹配',
                r'类型转换失败'
            ],
            # 唯一约束异常
            'unique_constraint': [
                r'duplicate key value violates unique constraint',
                r'唯一性约束冲突',
                r'重复数据'
            ]
        }

        # 中文异常判断模式（如果已经是中文且符合规范，直接返回）
        self.chinese_patterns = [
            r'^字段["\']?([^"\'\s]+)["\']?(不能为空|缺少数据|格式不正确|长度超过限制)',
            r'^任务(同步失败|处理失败|发布中断)',
            r'^请(检查|修复|调整|重新发布)'
        ]

        # 服务中断关键词
        self.service_interruption_keywords = [
            'failed', '中断', '不可用', '拒绝连接', 'timeout', '超时',
            'connection refused', '服务停止', '资源不可用'
        ]

        # 数据问题关键词
        self.data_problem_keywords = [
            'null', '空值', '格式', '长度', '类型', '约束', '唯一',
            'duplicate', 'invalid', '无效', '错误'
        ]

    def desensitize(self, text: str) -> str:
        """对敏感信息进行脱敏处理"""
        if not text:
            return text

        # 先保存字段名，避免被脱敏
        field_pattern = r'["\']([^"\']+)["\']'
        fields = re.findall(field_pattern, text)
        field_replacements = {}

        # 临时替换字段名
        for i, field in enumerate(fields):
            placeholder = f'__FIELD_{i}__'
            field_replacements[placeholder] = field
            text = text.replace(f'"{field}"', f'"{placeholder}"')
            text = text.replace(f"'{field}'", f"'{placeholder}'")

        # IP地址脱敏：前两段 + *.*
        ip_pattern = r'(\d{1,3}\.\d{1,3})\.\d{1,3}\.\d{1,3}(:\d+)?'
        def ip_replacer(match):
            ip = match.group(1)
            port = match.group(2) if match.group(2) else ''
            return f'{ip}.*.*{port}'
        text = re.sub(ip_pattern, ip_replacer, text)

        # 主机名脱敏：保留前部，其余用 * 替代
        host_pattern = r'\b([a-zA-Z0-9\-]+)\-[a-zA-Z0-9\-]+\b'
        def host_replacer(match):
            prefix = match.group(1)
            return f'{prefix}-***'
        text = re.sub(host_pattern, host_replacer, text)

        # 用户名脱敏：保留首字符 + ***（避免脱敏字段名）
        user_pattern = r'\b(user[=:\s]+)([a-zA-Z])[a-zA-Z0-9_]+\b'
        def user_replacer(match):
            prefix = match.group(1)
            first_char = match.group(2)
            return f'{prefix}{first_char}***'
        text = re.sub(user_pattern, user_replacer, text, flags=re.IGNORECASE)

        # 密码/密钥脱敏
        text = re.sub(r'password[=:\s]+["\']?[^"\'\s]+["\']?', 'password=***', text, flags=re.IGNORECASE)
        text = re.sub(r'key[=:\s]+["\']?[^"\'\s]+["\']?', 'key=***', text, flags=re.IGNORECASE)
        text = re.sub(r'token[=:\s]+["\']?[^"\'\s]+["\']?', 'token=***', text, flags=re.IGNORECASE)

        # 恢复字段名
        for placeholder, field in field_replacements.items():
            text = text.replace(f'"{placeholder}"', f'"{field}"')
            text = text.replace(f"'{placeholder}'", f"'{field}'")

        return text

    def is_already_chinese_error(self, error_text: str) -> bool:
        """判断是否已经是符合规范的中文异常提示"""
        error_text_lower = error_text.lower()

        # 检查是否包含技术术语
        technical_terms = ['flink', 'jdbc', 'constraint', 'exception', 'stack',
                          'batch', 'sql', 'java', 'class', 'method', 'error',
                          'failed', 'exception']
        for term in technical_terms:
            if term in error_text_lower:
                return False

        # 检查是否符合中文异常模式
        for pattern in self.chinese_patterns:
            if re.search(pattern, error_text):
                return True

        # 检查是否已经是完整的业务提示
        if re.search(r'请(检查|修复|调整|重新发布)', error_text) and \
           not re.search(r'[a-zA-Z]{3,}', error_text):  # 不包含长英文单词
            return True

        return False

    def extract_field_name(self, error_text: str) -> Optional[str]:
        """从异常信息中提取字段名"""
        # 尝试从各种模式中提取字段名
        field_patterns = [
            r'column ["\']([^"\']+)["\']',  # column "field_name"
            r'Column[\'"]([^"\']+)[\'"]',    # Column'field_name'
            r'字段["\']([^"\']+)["\']',      # 字段"字段名"
            r'field ["\']([^"\']+)["\']',    # field "field_name"
            r'["\']([^"\']+)["\']字段',      # "字段名"字段
        ]

        for pattern in field_patterns:
            match = re.search(pattern, error_text)
            if match:
                field = match.group(1)
                # 清理字段名
                field = field.strip('"\':')
                # 检查是否是有效的字段名（不是值）
                if self.is_valid_field_name(field):
                    return field

        return None

    def is_valid_field_name(self, text: str) -> bool:
        """检查是否是有效的字段名（不是值）"""
        if len(text) <= 1:
            return False

        # 排除明显是值的模式
        value_patterns = [
            r'^\d{4}-\d{2}-\d{2}$',  # 日期格式
            r'^\d+$',                # 纯数字
            r'^\d+\.\d+$',           # 小数
            r'^[a-f0-9]{8}-',        # UUID开头
        ]

        for pattern in value_patterns:
            if re.match(pattern, text):
                return False

        # 检查是否包含常见值关键词
        value_keywords = ['value', 'data', 'content', '信息', '数据', '内容']
        for keyword in value_keywords:
            if keyword in text.lower():
                return False

        return True

    def classify_error_type(self, error_text: str) -> Tuple[str, Optional[str]]:
        """分类错误类型并提取相关信息"""
        error_text_lower = error_text.lower()

        # 首先进行模式匹配（更精确）
        for error_type, patterns in self.patterns.items():
            for pattern in patterns:
                match = re.search(pattern, error_text_lower)
                if match:
                    # 尝试提取字段名
                    field = None
                    if error_type in ['null_value', 'format_error']:
                        field = self.extract_field_name(error_text)
                    elif match.lastindex and match.group(1):
                        field = match.group(1)
                    return error_type, field

        # 检查服务中断关键词
        for keyword in self.service_interruption_keywords:
            if keyword in error_text_lower:
                return 'service_interruption', None

        # 检查数据问题关键词
        for keyword in self.data_problem_keywords:
            if keyword in error_text_lower:
                field = self.extract_field_name(error_text)
                return 'data_problem', field

        return 'unknown', None

    def generate_human_readable_message(self, error_text: str) -> str:
        """生成人类可读的错误消息"""
        # 检查是否已经是符合规范的中文异常
        if self.is_already_chinese_error(error_text):
            return error_text

        # 脱敏处理
        error_text_desensitized = self.desensitize(error_text)

        # 分类错误类型（使用原始文本进行分类，避免脱敏影响分类）
        error_type, field = self.classify_error_type(error_text)

        # 根据错误类型生成消息
        messages = {
            'null_value': f"任务同步失败，字段'{field if field else '未知字段'}'缺少数据导致无法保存，请补齐该字段后重新发布任务。",
            'format_error': f"任务同步失败，由于{field if field else '日期'}字段格式不正确导致无法处理，请修正格式后重新发布任务。",
            'service_interruption': "任务发布中断，承载任务的服务可能暂时不可用，请确认其恢复正常后重新发布任务。",
            'length_error': f"任务同步失败，字段'{field if field else '内容'}'过长超出限制，请缩短内容后重新发布任务。",
            'type_error': f"任务同步失败，字段'{field if field else '数据'}'类型不正确，请修正后重新发布任务。",
            'unique_constraint': f"任务同步失败，字段'{field if field else '数据'}'存在重复导致无法保存，请检查并修正后重新发布任务。",
            'data_problem': f"任务同步失败，{f'字段\"{field}\"' if field else '数据'}存在问题导致无法处理，请修复后重新发布任务。",
            'unknown': "任务处理失败，请检查数据后重新发布任务。"
        }

        message = messages.get(error_type, messages['unknown'])

        # 如果原始文本包含IP等信息，在服务中断消息中显示脱敏后的信息
        if error_type == 'service_interruption':
            # 提取脱敏后的IP信息
            ip_match = re.search(r'(\d+\.\d+\..*?:\d+)', error_text_desensitized)
            if ip_match:
                ip_info = ip_match.group(1)
                message = f"任务发布中断，承载任务的服务 {ip_info} 可能不可用，请确认其恢复正常后重新发布任务。"
            else:
                # 检查是否有主机名
                host_match = re.search(r'([a-zA-Z0-9\-]+\-\*\*\*)', error_text_desensitized)
                if host_match:
                    host_info = host_match.group(1)
                    message = f"任务发布中断，承载任务的服务 {host_info} 可能不可用，请确认其恢复正常后重新发布任务。"

        return message

    def parse(self, error_text: str) -> str:
        """主解析函数"""
        if not error_text or not error_text.strip():
            return "未提供异常信息"

        try:
            return self.generate_human_readable_message(error_text.strip())
        except Exception as e:
            return f"异常解析失败: {str(e)}"


def main():
    """命令行入口"""
    import sys

    parser = FlinkErrorParser()

    if len(sys.argv) > 1:
        # 从命令行参数读取
        error_text = ' '.join(sys.argv[1:])
    else:
        # 从标准输入读取
        error_text = sys.stdin.read().strip()

    if not error_text:
        print("请提供异常信息")
        sys.exit(1)

    result = parser.parse(error_text)
    print(result)


if __name__ == "__main__":
    main()