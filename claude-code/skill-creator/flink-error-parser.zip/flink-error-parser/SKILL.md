---
name: flink-error-parser
description: 将 Flink 任务执行过程中的技术堆栈异常信息转换成直观简洁的白话提示的技能。此技能应该在使用者需要处理 Flink 任务异常、将技术异常转换为业务用户可理解的消息、或在 SaaS 平台中展示用户友好的错误提示时使用。
---

# Flink 异常解析器技能

## 概述

此技能提供将 Flink 任务执行过程中的技术堆栈异常信息转换成直观简洁白话提示的专业能力。通过集成的 Python 解析器，可以将复杂的异常堆栈信息转换为适合展示在 SaaS 平台消息栏的业务化提示。

### 核心价值
- **技术异常业务化**：将技术术语转换为业务用户能理解的语言
- **敏感信息脱敏**：自动脱敏 IP、主机名、用户名等敏感信息
- **智能分类处理**：自动识别服务中断、数据问题等不同类型异常
- **规范输出**：遵循严格的输出规范，确保一致性

## 何时使用此技能

在以下场景中使用此技能：

### 1. Flink 任务异常处理
- 处理 Flink 任务执行失败的技术异常信息
- 将 JDBC、SQL、网络连接等异常转换为用户友好提示
- 在任务管理界面展示清晰的错误原因

### 2. SaaS 平台消息中心
- 在消息栏展示任务失败原因
- 提供明确的修复建议和下一步操作
- 避免向业务用户展示技术堆栈信息

### 3. 数据同步任务监控
- 监控数据同步任务的异常情况
- 自动生成修复指导
- 记录异常处理历史

### 4. 技术支持与排错
- 快速理解异常根本原因
- 提供标准化的错误分类
- 生成可执行的修复建议

## 快速开始

### 安装与配置
此技能包含完整的 Python 实现，无需额外安装依赖：

```bash
# 查看技能目录结构
ls .claude/skills/flink-error-parser/

# 运行测试验证功能
python .claude/skills/flink-error-parser/scripts/test_parser.py
```

### 基本使用示例

#### 示例 1：命令行使用
```bash
# 直接解析异常信息
python scripts/flink_error_parser.py "Batch entry 6 INSERT INTO ... ERROR: null value in column 'bigint_field' violates not-null constraint"

# 输出：任务同步失败，字段"bigint_field"缺少数据导致无法保存，请补齐该字段后重新发布任务。
```

#### 示例 2：Python 代码集成
```python
from scripts.flink_error_parser import FlinkErrorParser

# 创建解析器实例
parser = FlinkErrorParser()

# 解析异常信息
error_message = "date/time field value out of range: '2025-13-01'"
result = parser.parse(error_message)
print(result)  # 任务同步失败，由于日期字段格式不正确导致无法处理，请修正日期格式后重新发布任务。
```

#### 示例 3：处理包含敏感信息的异常
```python
error_message = "Failed to connect to database at jdbc:postgresql://192.168.1.100:5432/mydb?user=admin&password=secret123"
result = parser.parse(error_message)
print(result)  # 任务发布中断，承载任务的服务 192.168.*.*:5432 可能不可用，请确认其恢复正常后重新发布任务。
```

## 核心功能

### 1. 异常信息解析
解析器支持多种异常模式识别：

#### 字段缺失/空值异常
- 模式：`null value in column "field_name" violates not-null constraint`
- 模式：`Column'字段名'cannotbenull`
- 输出：`任务同步失败，字段"字段名"缺少数据导致无法保存，请补齐该字段后重新发布任务。`

#### 格式错误异常
- 模式：`date/time field value out of range: "value"`
- 模式：`无效的日期格式: "value"`
- 输出：`任务同步失败，由于日期字段格式不正确导致无法处理，请修正日期格式后重新发布任务。`

#### 服务中断异常
- 模式：`host 192.168.1.1:5432 failed unexpectedly`
- 模式：`Connection refused: connect to host`
- 输出：`任务发布中断，承载任务的服务 192.168.*.*:5432 可能不可用，请确认其恢复正常后重新发布任务。`

#### 数据长度异常
- 模式：`value too long for type character varying(255)`
- 输出：`任务同步失败，字段内容过长超出限制，请缩短内容后重新发布任务。`

#### 数据类型异常
- 模式：`invalid input syntax for type integer: "abc"`
- 输出：`任务同步失败，字段数据类型不正确，请修正后重新发布任务。`

#### 唯一约束异常
- 模式：`duplicate key value violates unique constraint "constraint_name"`
- 输出：`任务同步失败，存在重复数据导致无法保存，请检查并修正后重新发布任务。`

### 2. 敏感信息脱敏
自动脱敏以下敏感信息：

#### IP地址脱敏
- 输入：`172.30.34.3:6122`
- 输出：`172.30.*.*:6122`
- 规则：保留前两段，后两段替换为`*.*`

#### 主机名脱敏
- 输入：`host-prod-database-123`
- 输出：`host-***`
- 规则：保留前缀，其余替换为`***`

#### 用户名脱敏
- 输入：`admin_user`
- 输出：`a***`
- 规则：保留首字符，其余替换为`***`

#### 密码/密钥脱敏
- 输入：`password=secret123`
- 输出：`password=***`
- 规则：完全替换为`***`

### 3. 中文异常判断
如果输入已经是符合规范的中文异常提示，直接返回原文：

#### 符合条件的中文异常
- `字段"id"不能为空，请检查后重新发布任务。`
- `任务同步失败，字段"名称"缺少数据导致无法保存。`
- `请检查配置后重新发布任务。`

#### 不符合条件（需要处理）
- 包含技术术语：`Flink任务执行失败`
- 包含英文：`Column 'id' cannot be null`
- 不符合规范格式

### 4. 错误分类处理
根据异常类型采用不同的处理策略：

#### 服务中断类异常
- **特征**：外部环境中断、服务停止、资源不可用
- **输出模板**：`任务发布中断，承载任务的服务可能暂时不可用，请确认其恢复正常后重新发布任务。`
- **关键词**：`failed`、`中断`、`不可用`、`拒绝连接`、`timeout`

#### 数据问题类异常
- **特征**：字段缺失、格式错误、配置错误、数据问题
- **输出模板**：`任务同步失败，[字段"字段名"]存在问题导致无法处理，请修复后重新发布任务。`
- **关键词**：`null`、`空值`、`格式`、`长度`、`类型`、`约束`

## 工作流程

### 步骤 1：接收异常信息
从以下来源获取异常信息：
- Flink 任务日志
- 数据库错误日志
- 应用程序异常捕获
- 用户提交的错误报告

### 步骤 2：调用解析器
```python
from scripts.flink_error_parser import FlinkErrorParser

parser = FlinkErrorParser()
user_friendly_message = parser.parse(raw_error_message)
```

### 步骤 3：处理解析结果
根据解析结果采取相应行动：

#### 服务中断类
1. 记录服务不可用事件
2. 触发服务健康检查
3. 通知相关人员检查服务状态
4. 在界面显示"请重新发布任务"提示

#### 数据问题类
1. 记录具体字段和数据问题
2. 提供字段级修复指导
3. 在界面显示"请修复后重新发布任务"提示
4. 提供数据验证工具链接

#### 未知错误类
1. 记录原始异常信息
2. 触发人工审核流程
3. 在界面显示通用错误提示
4. 提供技术支持联系方式

### 步骤 4：展示与反馈
1. 在消息中心展示解析后的提示
2. 记录解析历史供后续分析
3. 收集用户反馈优化解析规则
4. 定期更新异常模式库

## 集成指南

### 集成到任务管理系统
```python
class TaskManager:
    def __init__(self):
        from scripts.flink_error_parser import FlinkErrorParser
        self.error_parser = FlinkErrorParser()

    def handle_task_failure(self, task_id, error_message):
        """处理任务失败"""
        # 解析异常信息
        user_message = self.error_parser.parse(error_message)

        # 更新任务状态
        self.update_task_status(task_id, 'failed', user_message)

        # 发送通知
        self.send_notification(task_id, user_message)

        # 记录日志
        self.log_error(task_id, error_message, user_message)

        return user_message
```

### 集成到消息中心
```python
class MessageCenter:
    def __init__(self):
        from scripts.flink_error_parser import FlinkErrorParser
        self.parser = FlinkErrorParser()

    def add_error_message(self, user_id, task_name, error_message):
        """添加错误消息到消息中心"""
        # 解析异常
        friendly_message = self.parser.parse(error_message)

        # 创建消息
        message = {
            'type': 'error',
            'user_id': user_id,
            'title': f'任务"{task_name}"执行失败',
            'content': friendly_message,
            'timestamp': datetime.now(),
            'metadata': {
                'original_error': error_message,
                'parsed': True
            }
        }

        # 保存到数据库
        self.save_message(message)

        return message
```

### 集成到监控告警系统
```python
class MonitoringSystem:
    def __init__(self):
        from scripts.flink_error_parser import FlinkErrorParser
        self.parser = FlinkErrorParser()

    def process_alert(self, alert):
        """处理监控告警"""
        if alert['type'] == 'flink_task_error':
            # 解析异常信息
            user_message = self.parser.parse(alert['error_message'])

            # 分类处理
            error_type, _ = self.parser.classify_error_type(alert['error_message'])

            if error_type == 'service_interruption':
                # 服务中断，触发紧急处理
                self.trigger_emergency_response(alert, user_message)
            else:
                # 数据问题，记录并通知
                self.record_and_notify(alert, user_message)

            return user_message
```

## 最佳实践

### 1. 异常信息收集
- 收集完整的异常堆栈信息
- 包含上下文信息（任务ID、执行时间、数据源等）
- 记录异常发生时的环境状态

### 2. 解析时机选择
- **实时解析**：任务失败时立即解析并展示
- **批量解析**：定期解析历史异常日志
- **按需解析**：用户查看错误详情时解析

### 3. 结果展示优化
- 在消息中心突出显示关键信息
- 提供"查看原始错误"链接
- 根据错误类型显示不同的图标和颜色
- 提供一键修复或重试操作

### 4. 监控与优化
- 监控解析成功率
- 收集用户反馈
- 定期更新异常模式库
- 分析常见错误模式

### 5. 安全考虑
- 确保脱敏规则覆盖所有敏感信息
- 验证用户权限后再展示原始错误
- 记录解析操作日志
- 定期审计脱敏规则

## 故障排除

### 常见问题

#### 1. 解析结果不符合预期
- **检查**：原始异常信息是否完整
- **检查**：是否包含技术术语需要脱敏
- **检查**：异常模式是否在模式库中
- **解决**：运行测试脚本验证解析逻辑

#### 2. 脱敏不彻底
- **检查**：敏感信息模式是否匹配
- **检查**：脱敏规则是否正确配置
- **解决**：添加自定义脱敏规则

#### 3. 性能问题
- **检查**：异常信息长度是否过大
- **检查**：是否频繁创建解析器实例
- **解决**：复用解析器实例，优化正则表达式

#### 4. 中文异常误判
- **检查**：中文异常是否符合规范
- **检查**：是否包含技术术语
- **解决**：调整中文异常判断逻辑

### 调试工具
使用内置测试工具进行调试：

```bash
# 运行完整测试套件
python scripts/test_parser.py --mode all

# 测试特定异常
python scripts/test_parser.py --error "您的异常信息"

# 交互式测试
python scripts/test_parser.py --mode interactive

# 测试脱敏功能
python scripts/test_parser.py --mode desensitize

# 测试错误分类
python scripts/test_parser.py --mode classification
```

## 扩展开发

### 添加自定义异常模式
```python
class CustomFlinkErrorParser(FlinkErrorParser):
    def __init__(self):
        super().__init__()

        # 添加自定义异常模式
        self.patterns['custom_error'] = [
            r'自定义错误模式: ([^"\']+)',
            r'Custom error: ([^"\']+)'
        ]

    def generate_human_readable_message(self, error_text):
        # 先调用父类处理
        result = super().generate_human_readable_message(error_text)

        # 自定义处理逻辑
        if '自定义错误' in error_text:
            field = self.extract_field_name(error_text)
            if field:
                return f"任务处理失败，字段'{field}'存在自定义错误，请检查配置后重新发布任务。"
            else:
                return "任务处理失败，存在自定义错误，请检查配置后重新发布任务。"

        return result
```

### 支持多语言
```python
class MultilingualFlinkErrorParser(FlinkErrorParser):
    def __init__(self, language='zh'):
        super().__init__()
        self.language = language

        # 多语言消息模板
        self.message_templates = {
            'zh': {
                'null_value': "任务同步失败，字段'{field}'缺少数据导致无法保存，请补齐该字段后重新发布任务。",
                'format_error': "任务同步失败，由于{field}字段格式不正确导致无法处理，请修正格式后重新发布任务。",
                'service_interruption': "任务发布中断，承载任务的服务可能暂时不可用，请确认其恢复正常后重新发布任务。",
            },
            'en': {
                'null_value': "Task synchronization failed, field '{field}' is missing data and cannot be saved. Please fill in this field and republish the task.",
                'format_error': "Task synchronization failed due to incorrect format in the {field} field. Please correct the format and republish the task.",
                'service_interruption': "Task publication interrupted, the service carrying the task may be temporarily unavailable. Please confirm it has returned to normal and republish the task.",
            }
        }

    def generate_human_readable_message(self, error_text):
        # 获取错误类型
        error_type, field = self.classify_error_type(error_text)

        # 获取对应语言的模板
        template = self.message_templates.get(self.language, {}).get(error_type)

        if template:
            field_display = field if field else ('字段' if self.language == 'zh' else 'field')
            return template.format(field=field_display)
        else:
            # 回退到父类处理
            return super().generate_human_readable_message(error_text)
```

## 资源文件

### scripts/
包含可执行的 Python 脚本：

#### flink_error_parser.py
核心解析器实现，包含：
- 异常模式识别
- 敏感信息脱敏
- 错误分类处理
- 中文异常判断

#### test_parser.py
测试和验证工具，包含：
- 单元测试用例
- 脱敏功能测试
- 错误分类测试
- 交互式测试模式

### references/
参考文档：

#### usage_examples.md
使用示例和规范说明，包含：
- 核心规范要求
- 示例测试用例
- 使用方式指南
- 扩展开发建议

### assets/
（当前未使用，可根据需要添加模板文件）
