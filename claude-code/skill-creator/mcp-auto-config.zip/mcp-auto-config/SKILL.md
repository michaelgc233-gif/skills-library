---
name: mcp-auto-config
description: 自动化配置 Claude Code MCP 服务器的技能。此技能应该在使用者需要批量配置、更新或管理 MCP 服务器时使用，支持根据 JSON 配置自动创建、更新或替换 MCP 服务器配置，并支持 user、project、local 三种作用域。
---

# MCP 自动化配置技能

## 概述

此技能提供自动化配置 Claude Code MCP (Model Context Protocol) 服务器的能力。通过接收 JSON 格式的 MCP 服务器配置，自动更新相应的配置文件，支持三种作用域配置，并实现同名服务器的直接覆盖替换。

## 核心功能

### 1. 自动化配置管理
- **智能检测**：自动检测现有配置，避免重复
- **覆盖替换**：同名服务器直接覆盖，无需手动删除
- **作用域支持**：支持 user（全局）、project（项目）、local（本地）三种作用域
- **配置验证**：验证 JSON 配置格式和必填字段

### 2. 配置文件处理
- **全局配置**：更新 `~/.claude.json` 中的 MCP 服务器配置
- **项目配置**：创建或更新项目目录下的 `.mcp.json` 文件
- **本地配置**：更新 `~/.claude.json` 中的项目特定配置
- **备份机制**：修改前自动备份原配置文件

### 3. 用户交互
- **配置预览**：显示将要应用的配置变更
- **确认机制**：应用前与用户确认配置内容
- **结果反馈**：显示配置结果和生效方式

## 使用场景

此技能应该在以下场景中使用：

1. **批量配置 MCP 服务器**：需要一次性配置多个 MCP 服务器时
2. **团队项目配置**：为项目团队统一配置共享的 MCP 服务器
3. **配置迁移**：将 MCP 配置从一个环境迁移到另一个环境
4. **配置标准化**：确保团队使用统一的 MCP 服务器配置
5. **快速部署**：新项目快速配置所需的 MCP 工具链

## 快速开始

### 基本使用流程

1. **准备 JSON 配置**
   ```json
   {
     "scope": "project",  // 或 "user"、"local"
     "servers": {
       "github": {
         "type": "http",
         "url": "https://api.githubcopilot.com/mcp/"
       },
       "filesystem": {
         "type": "stdio",
         "command": "npx",
         "args": ["-y", "@modelcontextprotocol/server-filesystem"]
       }
     }
   }
   ```

2. **执行配置**
   - 使用 `scripts/configure_mcp.py` 脚本
   - 或通过 Claude 交互式配置

3. **确认配置**
   - 查看配置预览
   - 确认应用配置
   - 查看配置结果

### 配置参数说明

#### scope（作用域）
- **user**：用户全局配置，存储在 `~/.claude.json`
- **project**：项目配置，存储在项目目录的 `.mcp.json`
- **local**：本地配置，存储在 `~/.claude.json` 的项目特定路径

#### servers（服务器配置）
每个服务器支持以下配置项：
- **type**：传输类型，支持 `stdio`、`http`、`sse`
- **command**：stdio 类型的执行命令
- **args**：stdio 类型的命令行参数
- **url**：http/sse 类型的服务器 URL
- **headers**：http 类型的请求头
- **env**：环境变量配置

## 详细工作流程

### 步骤 1：分析配置需求
- 确定要配置的 MCP 服务器列表
- 选择合适的作用域（user/project/local）
- 准备 JSON 配置数据

### 步骤 2：执行配置脚本
```bash
# 使用 Python 脚本
python scripts/configure_mcp.py --config mcp_config.json

# 或通过 Claude 交互
# 提供 JSON 配置，Claude 会调用脚本处理
```

### 步骤 3：配置验证与确认
1. **读取现有配置**：检查目标配置文件
2. **生成配置变更**：计算需要添加/更新的服务器
3. **显示配置预览**：展示将要应用的变更
4. **用户确认**：等待用户确认后应用

### 步骤 4：应用配置
1. **备份原配置**：自动创建备份文件
2. **更新配置文件**：应用新的 MCP 配置
3. **验证配置格式**：确保 JSON 格式正确
4. **显示结果**：反馈配置成功/失败信息

### 步骤 5：生效与验证
- **立即生效**：大多数配置立即生效
- **需要重启**：插件服务器需要重启 Claude Code
- **验证命令**：使用 `claude mcp list` 验证配置

## 配置示例

### 示例 1：项目级团队配置
```json
{
  "scope": "project",
  "servers": {
    "github": {
      "type": "http",
      "url": "https://api.githubcopilot.com/mcp/"
    },
    "sentry": {
      "type": "http",
      "url": "https://mcp.sentry.dev/mcp"
    },
    "postgres": {
      "type": "stdio",
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-postgres"]
    }
  }
}
```

### 示例 2：个人全局配置
```json
{
  "scope": "user",
  "servers": {
    "weather": {
      "type": "http",
      "url": "https://api.weather.com/mcp"
    },
    "filesystem": {
      "type": "stdio",
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-filesystem"]
    }
  }
}
```

### 示例 3：带认证的服务器配置
```json
{
  "scope": "local",
  "servers": {
    "jira": {
      "type": "http",
      "url": "https://mcp.atlassian.com/mcp",
      "headers": {
        "Authorization": "Bearer ${JIRA_TOKEN}"
      }
    },
    "openai": {
      "type": "http",
      "url": "https://api.openai.com/mcp",
      "headers": {
        "Authorization": "Bearer ${OPENAI_API_KEY}"
      }
    }
  }
}
```

## 错误处理

### 常见错误及解决方案

1. **配置文件不存在**
   - 自动创建配置文件
   - 确保目录权限正确

2. **JSON 格式错误**
   - 验证 JSON 语法
   - 提供详细的错误信息

3. **作用域配置冲突**
   - 检查作用域是否支持
   - 提供替代方案建议

4. **权限不足**
   - 检查文件写入权限
   - 建议使用合适的作用域

### 错误响应格式
```json
{
  "success": false,
  "error": "错误类型",
  "message": "详细错误信息",
  "suggestion": "解决建议"
}
```

## 最佳实践

### 1. 作用域选择策略
- **团队共享工具** → 使用 `project` 作用域
- **个人开发工具** → 使用 `user` 作用域
- **项目特定配置** → 使用 `local` 作用域
- **敏感凭证配置** → 使用环境变量，避免硬编码

### 2. 配置管理建议
- **版本控制**：将 `project` 作用域的 `.mcp.json` 加入版本控制
- **配置文档**：为团队维护 MCP 服务器使用文档
- **定期审查**：定期清理不再使用的 MCP 配置
- **备份策略**：重要配置修改前手动备份

### 3. 安全注意事项
- **敏感信息**：使用环境变量代替硬编码的 API 密钥
- **权限控制**：仅配置必要的 MCP 服务器
- **来源验证**：仅使用可信的 MCP 服务器 URL
- **网络隔离**：生产环境注意网络访问控制

## 脚本说明

### `scripts/configure_mcp.py`
主配置脚本，提供以下功能：
- 解析 JSON 配置
- 处理不同作用域的配置文件
- 实现配置的合并与覆盖
- 提供用户交互确认
- 备份和恢复机制

### 使用方式
```bash
# 基本使用
python scripts/configure_mcp.py --config mcp_config.json

# 指定作用域（覆盖 JSON 中的 scope）
python scripts/configure_mcp.py --config mcp_config.json --scope project

# 静默模式（无需确认）
python scripts/configure_mcp.py --config mcp_config.json --yes

# 仅预览不应用
python scripts/configure_mcp.py --config mcp_config.json --dry-run
```

## 参考资源

- `references/mcp-config-format.md`：MCP 配置格式详细说明
- `references/claude-mcp-guide.md`：Claude Code MCP 使用指南
- `references/scope-decision-tree.md`：作用域选择决策树

## 注意事项

1. **配置生效时间**：大多数配置立即生效，插件服务器需要重启 Claude Code
2. **环境变量**：配置文件中支持 `${VAR}` 环境变量扩展
3. **网络要求**：http 类型的服务器需要网络连接
4. **权限要求**：写入配置文件需要相应的文件系统权限
5. **兼容性**：确保 MCP 服务器版本与 Claude Code 兼容
