#!/usr/bin/env python3
"""
MCP 自动化配置脚本

功能：
1. 根据 JSON 配置自动创建、更新或替换 MCP 服务器配置
2. 支持 user、project、local 三种作用域
3. 同名服务器直接覆盖替换
4. 配置前预览，配置后确认

使用方式：
python configure_mcp.py --config mcp_config.json
python configure_mcp.py --config mcp_config.json --scope project
python configure_mcp.py --config mcp_config.json --yes
python configure_mcp.py --config mcp_config.json --dry-run
"""

import os
import json
import sys
import argparse
import shutil
from pathlib import Path
from typing import Dict, Any, Optional, List
import tempfile

class MCPConfigurator:
    """MCP 配置管理器"""

    def __init__(self, verbose: bool = False):
        self.verbose = verbose
        self.home_dir = Path.home()

    def log(self, message: str, level: str = "INFO"):
        """日志输出"""
        if self.verbose or level in ["ERROR", "WARNING"]:
            print(f"[{level}] {message}")

    def get_config_path(self, scope: str, project_path: Optional[str] = None) -> Path:
        """获取配置文件路径

        Args:
            scope: 作用域，支持 'user', 'project', 'local'
            project_path: 项目路径（仅 project 和 local 作用域需要）

        Returns:
            Path: 配置文件路径
        """
        if scope == "user":
            # 用户全局配置
            return self.home_dir / ".claude.json"
        elif scope == "project":
            # 项目配置
            if not project_path:
                project_path = os.getcwd()
            return Path(project_path) / ".mcp.json"
        elif scope == "local":
            # 本地配置（用户配置中的项目特定配置）
            return self.home_dir / ".claude.json"
        else:
            raise ValueError(f"不支持的作用域: {scope}")

    def read_config(self, config_path: Path) -> Dict[str, Any]:
        """读取配置文件

        Args:
            config_path: 配置文件路径

        Returns:
            Dict: 配置内容，文件不存在时返回空字典
        """
        if not config_path.exists():
            self.log(f"配置文件不存在: {config_path}", "INFO")
            return {}

        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                content = f.read().strip()
                if not content:
                    return {}
                return json.loads(content)
        except json.JSONDecodeError as e:
            self.log(f"配置文件 JSON 格式错误: {config_path} - {e}", "ERROR")
            raise
        except Exception as e:
            self.log(f"读取配置文件失败: {config_path} - {e}", "ERROR")
            raise

    def write_config(self, config_path: Path, config: Dict[str, Any]) -> None:
        """写入配置文件

        Args:
            config_path: 配置文件路径
            config: 配置内容
        """
        # 确保目录存在
        config_path.parent.mkdir(parents=True, exist_ok=True)

        # 写入配置文件
        try:
            with open(config_path, 'w', encoding='utf-8') as f:
                json.dump(config, f, indent=2, ensure_ascii=False)
            self.log(f"配置文件已保存: {config_path}", "INFO")
        except Exception as e:
            self.log(f"写入配置文件失败: {config_path} - {e}", "ERROR")
            raise

    def backup_config(self, config_path: Path) -> Optional[str]:
        """备份配置文件

        Args:
            config_path: 配置文件路径

        Returns:
            Optional[str]: 备份文件路径，未备份时返回 None
        """
        if not config_path.exists():
            return None

        # 创建备份文件
        backup_path = config_path.with_suffix(f".json.backup.{int(os.times().elapsed)}")
        try:
            shutil.copy2(config_path, backup_path)
            self.log(f"配置文件已备份: {backup_path}", "INFO")
            return str(backup_path)
        except Exception as e:
            self.log(f"备份配置文件失败: {config_path} - {e}", "WARNING")
            return None

    def validate_server_config(self, server_name: str, server_config: Dict[str, Any]) -> List[str]:
        """验证服务器配置

        Args:
            server_name: 服务器名称
            server_config: 服务器配置

        Returns:
            List[str]: 错误信息列表，空列表表示验证通过
        """
        errors = []

        # 检查必填字段
        if "type" not in server_config:
            errors.append(f"服务器 '{server_name}' 缺少 'type' 字段")
            return errors

        server_type = server_config["type"]

        # 根据类型检查必填字段
        if server_type == "stdio":
            if "command" not in server_config:
                errors.append(f"stdio 服务器 '{server_name}' 缺少 'command' 字段")
        elif server_type in ["http", "sse"]:
            if "url" not in server_config:
                errors.append(f"{server_type} 服务器 '{server_name}' 缺少 'url' 字段")
        else:
            errors.append(f"服务器 '{server_name}' 的 'type' 字段值无效: {server_type}")

        return errors

    def merge_config(self, existing_config: Dict[str, Any], new_servers: Dict[str, Any], scope: str) -> Dict[str, Any]:
        """合并配置

        Args:
            existing_config: 现有配置
            new_servers: 新的服务器配置
            scope: 作用域

        Returns:
            Dict: 合并后的配置
        """
        if scope == "local":
            # local 作用域需要特殊处理
            project_path = os.getcwd()
            if "projects" not in existing_config:
                existing_config["projects"] = {}

            if project_path not in existing_config["projects"]:
                existing_config["projects"][project_path] = {}

            if "mcpServers" not in existing_config["projects"][project_path]:
                existing_config["projects"][project_path]["mcpServers"] = {}

            # 合并服务器配置
            existing_config["projects"][project_path]["mcpServers"].update(new_servers)
        else:
            # user 和 project 作用域
            if "mcpServers" not in existing_config:
                existing_config["mcpServers"] = {}

            # 合并服务器配置
            existing_config["mcpServers"].update(new_servers)

        return existing_config

    def get_config_diff(self, existing_config: Dict[str, Any], new_servers: Dict[str, Any], scope: str) -> Dict[str, Any]:
        """获取配置差异

        Args:
            existing_config: 现有配置
            new_servers: 新的服务器配置
            scope: 作用域

        Returns:
            Dict: 配置差异信息
        """
        diff = {
            "added": [],
            "updated": [],
            "unchanged": []
        }

        if scope == "local":
            project_path = os.getcwd()
            existing_servers = existing_config.get("projects", {}).get(project_path, {}).get("mcpServers", {})
        else:
            existing_servers = existing_config.get("mcpServers", {})

        for server_name, server_config in new_servers.items():
            if server_name not in existing_servers:
                diff["added"].append(server_name)
            elif existing_servers[server_name] != server_config:
                diff["updated"].append(server_name)
            else:
                diff["unchanged"].append(server_name)

        return diff

    def configure(self, config_data: Dict[str, Any], auto_confirm: bool = False, dry_run: bool = False) -> Dict[str, Any]:
        """执行配置

        Args:
            config_data: 配置数据
            auto_confirm: 是否自动确认
            dry_run: 是否仅预览不实际应用

        Returns:
            Dict: 配置结果
        """
        result = {
            "success": False,
            "message": "",
            "backup_path": None,
            "config_path": None,
            "diff": None
        }

        try:
            # 验证配置数据
            if "scope" not in config_data:
                result["message"] = "配置数据缺少 'scope' 字段"
                return result

            if "servers" not in config_data:
                result["message"] = "配置数据缺少 'servers' 字段"
                return result

            scope = config_data["scope"]
            servers = config_data["servers"]
            project_path = config_data.get("project_path")

            # 验证作用域
            if scope not in ["user", "project", "local"]:
                result["message"] = f"不支持的作用域: {scope}"
                return result

            # 验证服务器配置
            all_errors = []
            for server_name, server_config in servers.items():
                errors = self.validate_server_config(server_name, server_config)
                if errors:
                    all_errors.extend(errors)

            if all_errors:
                result["message"] = "服务器配置验证失败:\n" + "\n".join(all_errors)
                return result

            # 获取配置文件路径
            config_path = self.get_config_path(scope, project_path)
            result["config_path"] = str(config_path)

            # 读取现有配置
            existing_config = self.read_config(config_path)

            # 获取配置差异
            diff = self.get_config_diff(existing_config, servers, scope)
            result["diff"] = diff

            # 显示配置预览
            print("\n" + "="*60)
            print("MCP 配置预览")
            print("="*60)
            print(f"作用域: {scope}")
            print(f"配置文件: {config_path}")
            print(f"新增服务器: {len(diff['added'])} 个")
            print(f"更新服务器: {len(diff['updated'])} 个")
            print(f"未变更服务器: {len(diff['unchanged'])} 个")

            if diff["added"]:
                print("\n新增服务器:")
                for server in diff["added"]:
                    print(f"  - {server}")

            if diff["updated"]:
                print("\n更新服务器:")
                for server in diff["updated"]:
                    print(f"  - {server}")

            print("\n" + "="*60)

            # 如果是 dry-run 模式，直接返回
            if dry_run:
                result["success"] = True
                result["message"] = "配置预览完成（dry-run 模式）"
                return result

            # 确认配置
            if not auto_confirm:
                confirm = input("\n是否应用此配置？(y/N): ").strip().lower()
                if confirm not in ["y", "yes"]:
                    result["message"] = "用户取消配置"
                    return result

            # 备份原配置
            backup_path = self.backup_config(config_path)
            result["backup_path"] = backup_path

            # 合并配置
            merged_config = self.merge_config(existing_config, servers, scope)

            # 写入配置
            self.write_config(config_path, merged_config)

            result["success"] = True
            result["message"] = "MCP 配置已成功应用"

            # 显示生效提示
            print("\n" + "="*60)
            print("配置生效提示")
            print("="*60)
            print("✓ 配置已保存")
            if backup_path:
                print(f"✓ 原配置已备份: {backup_path}")

            print("\n生效方式:")
            print("1. 大多数配置会立即生效")
            print("2. 插件提供的 MCP 服务器需要重启 Claude Code")
            print("3. 使用以下命令验证配置:")
            print("   claude mcp list")
            print("="*60)

        except Exception as e:
            result["message"] = f"配置过程中发生错误: {str(e)}"
            self.log(f"配置失败: {e}", "ERROR")

        return result

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description="MCP 自动化配置工具")
    parser.add_argument("--config", "-c", required=True, help="JSON 配置文件路径")
    parser.add_argument("--scope", "-s", choices=["user", "project", "local"],
                       help="覆盖配置文件中的作用域")
    parser.add_argument("--yes", "-y", action="store_true",
                       help="自动确认，无需用户输入")
    parser.add_argument("--dry-run", "-d", action="store_true",
                       help="仅预览配置，不实际应用")
    parser.add_argument("--verbose", "-v", action="store_true",
                       help="显示详细日志")

    args = parser.parse_args()

    # 读取配置文件
    try:
        with open(args.config, 'r', encoding='utf-8') as f:
            config_data = json.load(f)
    except FileNotFoundError:
        print(f"错误: 配置文件不存在: {args.config}")
        sys.exit(1)
    except json.JSONDecodeError as e:
        print(f"错误: 配置文件 JSON 格式错误: {e}")
        sys.exit(1)

    # 覆盖作用域（如果指定）
    if args.scope:
        config_data["scope"] = args.scope

    # 执行配置
    configurator = MCPConfigurator(verbose=args.verbose)
    result = configurator.configure(
        config_data,
        auto_confirm=args.yes,
        dry_run=args.dry_run
    )

    # 输出结果
    print(f"\n结果: {'成功' if result['success'] else '失败'}")
    print(f"消息: {result['message']}")

    if not result["success"]:
        sys.exit(1)

if __name__ == "__main__":
    main()