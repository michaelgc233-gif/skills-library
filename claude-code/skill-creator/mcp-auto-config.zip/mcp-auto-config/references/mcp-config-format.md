# MCP 配置格式详细说明

## 配置文件结构

### 1. 用户全局配置 (`~/.claude.json`)

```json
{
  "mcpServers": {
    "server-name": {
      "type": "stdio",  // 或 "http", "sse"
      "command": "/path/to/server",
      "args": ["--arg1", "value1"],
      "env": {
        "API_KEY": "${API_KEY}"
      }
    },
    "another-server": {
      "type": "http",
      "url": "https://api.example.com/mcp",
      "headers": {
        "Authorization": "Bearer ${TOKEN}"
      }
    }
  },
  "projects": {
    "/path/to/project": {
      "mcpServers": {
        "local-server": {
          "type": "stdio",
          "command": "python",
          "args": ["local_server.py"]
        }
      }
    }
  }
}
```

### 2. 项目配置 (`.mcp.json`)

```json
{
  "mcpServers": {
    "github": {
      "type": "http",
      "url": "https://api.githubcopilot.com/mcp/"
    },
    "postgres": {
      "type": "stdio",
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-postgres"]
    }
  }
}
```

## 配置字段说明

### type (必需)
传输类型，支持以下值：

#### `stdio` (标准输入输出)
本地进程服务器，通过标准输入输出通信。

**必需字段**：
- `command`: 执行命令
- `args`: 命令行参数数组

**可选字段**：
- `env`: 环境变量对象
- `cwd`: 工作目录

**示例**：
```json
{
  "type": "stdio",
  "command": "npx",
  "args": ["-y", "@modelcontextprotocol/server-filesystem"],
  "env": {
    "API_KEY": "${MY_API_KEY}"
  }
}
```

#### `http` (HTTP 协议)
通过 HTTP 协议通信的远程服务器。

**必需字段**：
- `url`: 服务器 URL

**可选字段**：
- `headers`: HTTP 请求头
- `timeout`: 超时时间（毫秒）

**示例**：
```json
{
  "type": "http",
  "url": "https://api.githubcopilot.com/mcp/",
  "headers": {
    "Authorization": "Bearer ${GITHUB_TOKEN}"
  },
  "timeout": 30000
}
```

#### `sse` (服务器发送事件)
通过 Server-Sent Events 通信（已弃用，推荐使用 http）。

**必需字段**：
- `url`: 服务器 URL

**示例**：
```json
{
  "type": "sse",
  "url": "https://api.example.com/mcp/sse"
}
```

## 环境变量支持

配置文件支持环境变量扩展，格式为 `${VAR_NAME}` 或 `${VAR_NAME:-default_value}`。

### 示例

```json
{
  "type": "http",
  "url": "${API_BASE_URL:-https://api.example.com}/mcp",
  "headers": {
    "Authorization": "Bearer ${API_KEY}"
  }
}
```

### 环境变量优先级
1. `${VAR}`: 使用环境变量 VAR 的值
2. `${VAR:-default}`: 如果 VAR 未设置，使用默认值
3. 硬编码值: 直接使用配置中的值

## 作用域配置详解

### 1. user 作用域 (用户全局)
- **配置文件**: `~/.claude.json`
- **存储位置**: 用户主目录
- **生效范围**: 对所有项目生效
- **适用场景**: 个人开发工具、全局工具

**配置位置**：
```json
{
  "mcpServers": {
    "weather": {
      "type": "http",
      "url": "https://api.weather.com/mcp"
    }
  }
}
```

### 2. project 作用域 (项目配置)
- **配置文件**: 项目目录下的 `.mcp.json`
- **存储位置**: 项目根目录
- **生效范围**: 仅对当前项目生效
- **适用场景**: 团队共享工具、项目特定工具

**配置位置**：
项目根目录的 `.mcp.json` 文件

### 3. local 作用域 (本地配置)
- **配置文件**: `~/.claude.json`
- **存储位置**: 用户主目录，项目特定路径下
- **生效范围**: 仅对指定项目生效
- **适用场景**: 项目特定的个人配置

**配置位置**：
```json
{
  "projects": {
    "/path/to/project": {
      "mcpServers": {
        "secret-tool": {
          "type": "http",
          "url": "https://internal.api.com/mcp"
        }
      }
    }
  }
}
```

## 配置验证规则

### 必填字段验证
| 类型 | 必填字段 | 可选字段 |
|------|----------|----------|
| `stdio` | `type`, `command` | `args`, `env`, `cwd` |
| `http` | `type`, `url` | `headers`, `timeout` |
| `sse` | `type`, `url` | `headers`, `timeout` |

### 字段类型验证
- `type`: 必须是 "stdio", "http", "sse" 之一
- `command`: 必须是字符串
- `args`: 必须是字符串数组
- `url`: 必须是有效的 URL 字符串
- `headers`: 必须是键值对对象
- `env`: 必须是键值对对象
- `timeout`: 必须是正整数

### 服务器名称规则
- 只能包含字母、数字、连字符和下划线
- 不能以连字符或下划线开头
- 长度在 1-50 个字符之间
- 不能与现有服务器重名（会覆盖）

## 配置示例集合

### 示例 1: GitHub Copilot
```json
{
  "github": {
    "type": "http",
    "url": "https://api.githubcopilot.com/mcp/"
  }
}
```

### 示例 2: 文件系统服务器
```json
{
  "filesystem": {
    "type": "stdio",
    "command": "npx",
    "args": ["-y", "@modelcontextprotocol/server-filesystem"]
  }
}
```

### 示例 3: PostgreSQL 服务器
```json
{
  "postgres": {
    "type": "stdio",
    "command": "npx",
    "args": ["-y", "@modelcontextprotocol/server-postgres"],
    "env": {
      "PGHOST": "${PGHOST}",
      "PGPORT": "${PGPORT}",
      "PGUSER": "${PGUSER}",
      "PGPASSWORD": "${PGPASSWORD}",
      "PGDATABASE": "${PGDATABASE}"
    }
  }
}
```

### 示例 4: 带认证的 API 服务器
```json
{
  "jira": {
    "type": "http",
    "url": "https://mcp.atlassian.com/mcp",
    "headers": {
      "Authorization": "Bearer ${JIRA_TOKEN}",
      "Content-Type": "application/json"
    }
  }
}
```

### 示例 5: 自定义本地服务器
```json
{
  "custom-server": {
    "type": "stdio",
    "command": "python",
    "args": ["/path/to/my_server.py", "--port", "8080"],
    "env": {
      "DEBUG": "true",
      "API_KEY": "${MY_API_KEY}"
    },
    "cwd": "/path/to/project"
  }
}
```

## 配置合并规则

### 同名服务器处理
- **新增**: 如果服务器不存在，直接添加
- **更新**: 如果服务器已存在，完全覆盖原配置
- **保留**: 未在配置中指定的服务器保持不变

### 配置合并示例

**现有配置**：
```json
{
  "mcpServers": {
    "github": {
      "type": "http",
      "url": "https://old.url/mcp"
    },
    "filesystem": {
      "type": "stdio",
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-filesystem"]
    }
  }
}
```

**新配置**：
```json
{
  "github": {
    "type": "http",
    "url": "https://api.githubcopilot.com/mcp/"
  },
  "postgres": {
    "type": "stdio",
    "command": "npx",
    "args": ["-y", "@modelcontextprotocol/server-postgres"]
  }
}
```

**合并结果**：
```json
{
  "mcpServers": {
    "github": {  // 更新
      "type": "http",
      "url": "https://api.githubcopilot.com/mcp/"
    },
    "filesystem": {  // 保留
      "type": "stdio",
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-filesystem"]
    },
    "postgres": {  // 新增
      "type": "stdio",
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-postgres"]
    }
  }
}
```

## 错误配置示例

### 错误 1: 缺少必填字段
```json
{
  "github": {
    "type": "http"
    // 缺少 url 字段
  }
}
```

### 错误 2: 类型不匹配
```json
{
  "server": {
    "type": "invalid-type",  // 无效的类型
    "command": "npx"
  }
}
```

### 错误 3: 字段类型错误
```json
{
  "server": {
    "type": "stdio",
    "command": "npx",
    "args": "invalid-args"  // args 应该是数组，不是字符串
  }
}
```

### 错误 4: 无效的 URL
```json
{
  "server": {
    "type": "http",
    "url": "not-a-valid-url"  // 无效的 URL
  }
}
```

## 最佳实践

### 1. 命名规范
- 使用小写字母和连字符
- 避免使用特殊字符
- 保持名称简洁明了
- 示例: `github`, `postgres`, `file-system`

### 2. 环境变量管理
- 敏感信息使用环境变量
- 提供默认值避免配置失败
- 在文档中说明所需环境变量
- 示例: `${API_KEY:-default-key}`

### 3. 配置组织
- 相关服务器分组配置
- 添加注释说明服务器用途
- 定期清理不再使用的配置
- 版本控制项目级配置

### 4. 安全性考虑
- 不要硬编码敏感信息
- 使用 HTTPS URL
- 验证服务器来源
- 限制不必要的服务器权限