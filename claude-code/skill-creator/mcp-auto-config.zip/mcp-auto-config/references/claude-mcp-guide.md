# Claude Code MCP 使用指南

## MCP 概述

MCP (Model Context Protocol) 是 Claude Code 与外部工具和服务通信的协议。通过 MCP，Claude 可以访问文件系统、数据库、API 等外部资源，扩展其能力范围。

## MCP 服务器类型

### 1. 官方 MCP 服务器
- **文件系统**: 访问本地文件系统
- **GitHub**: 与 GitHub 仓库交互
- **PostgreSQL**: 数据库查询和操作
- **天气**: 获取天气信息
- **时间**: 获取当前时间信息

### 2. 社区 MCP 服务器
- **Airtable**: Airtable 数据库访问
- **Slack**: Slack 消息发送
- **Google Calendar**: 日历管理
- **Jira**: 项目管理

### 3. 自定义 MCP 服务器
- 自行开发的专用工具
- 企业内部服务
- 特定领域工具

## MCP 配置命令

### 添加 MCP 服务器

#### HTTP 服务器
```bash
# 基本语法
claude mcp add --transport http <name> <url>

# 示例：添加 GitHub MCP 服务器
claude mcp add --transport http github https://api.githubcopilot.com/mcp/

# 带认证头
claude mcp add --transport http secure-api https://api.example.com/mcp \
  --header "Authorization: Bearer your-token"
```

#### Stdio 服务器（本地进程）
```bash
# 基本语法
claude mcp add --transport stdio <name> <command> [args...]

# 示例：添加文件系统服务器
claude mcp add --transport stdio filesystem \
  -- npx -y @modelcontextprotocol/server-filesystem

# 带环境变量
claude mcp add --transport stdio postgres \
  --env PGHOST=localhost --env PGPORT=5432 \
  -- npx -y @modelcontextprotocol/server-postgres
```

#### SSE 服务器（已弃用）
```bash
claude mcp add --transport sse <name> <url>
```

### 指定作用域

```bash
# 项目作用域（团队共享）
claude mcp add --transport http github --scope project https://api.githubcopilot.com/mcp/

# 用户作用域（个人全局）
claude mcp add --transport http hubspot --scope user https://mcp.hubspot.com/anthropic

# 本地作用域（项目特定，默认）
claude mcp add --transport http stripe --scope local https://mcp.stripe.com
```

### 管理 MCP 服务器

#### 列出所有服务器
```bash
claude mcp list
```

#### 获取服务器详情
```bash
claude mcp get <server-name>
```

#### 删除服务器
```bash
# 删除指定服务器
claude mcp remove <server-name>

# 删除项目作用域的服务器
claude mcp remove <server-name> --scope project
```

#### 重置项目选择
```bash
claude mcp reset-project-choices
```

## 在 Claude Code 中使用 MCP

### 检查 MCP 状态
在 Claude Code 会话中输入：
```
/mcp
```

这会显示：
- 所有已连接的 MCP 服务器
- 服务器状态（连接/断开）
- 可用的工具和资源

### 使用 MCP 工具

MCP 服务器提供的工具会自动出现在 Claude 的工具列表中。例如：

1. **文件系统服务器**：提供文件读写工具
2. **GitHub 服务器**：提供仓库操作工具
3. **数据库服务器**：提供查询执行工具

### 交互式认证

某些 MCP 服务器需要认证：
```
/mcp
# 选择需要认证的服务器
# 按照提示完成 OAuth 或 API 密钥配置
```

## 配置生效机制

### 立即生效
- 大多数 MCP 配置修改会立即生效
- 新的工具会立即出现在 Claude 的工具列表中
- 配置更改不需要重启 Claude Code

### 需要重启的情况
- 插件提供的 MCP 服务器
- 某些环境变量更改
- 系统级配置修改

### 验证配置生效
```bash
# 命令行验证
claude mcp list

# Claude Code 内验证
/mcp
```

## 环境变量配置

### 配置文件中的环境变量
```json
{
  "type": "http",
  "url": "${API_BASE_URL:-https://api.example.com}/mcp",
  "headers": {
    "Authorization": "Bearer ${API_KEY}"
  }
}
```

### 命令行环境变量
```bash
# 设置环境变量
export API_KEY=your-api-key
export API_BASE_URL=https://api.example.com

# 添加带环境变量的服务器
claude mcp add --transport stdio my-server \
  --env API_KEY=${API_KEY} \
  -- npx -y my-mcp-server
```

## 故障排查

### 常见问题

#### 1. 服务器连接失败
```bash
# 检查服务器状态
claude mcp get <server-name>

# 检查网络连接
curl <server-url>

# 检查防火墙设置
```

#### 2. 工具不可用
```
# 在 Claude Code 中
/mcp
# 检查服务器是否连接成功
# 检查工具列表是否包含预期工具
```

#### 3. 认证失败
```
# 重新认证
/mcp
# 选择服务器重新认证
# 或更新 API 密钥
```

#### 4. 配置不生效
```bash
# 检查配置文件
cat ~/.claude.json
cat .mcp.json

# 重启 Claude Code
# 某些配置需要重启才能生效
```

### 调试模式

启用详细日志：
```bash
# 设置环境变量
export MCP_DEBUG=true
export MCP_VERBOSE=true

# 重新启动 Claude Code
```

## 性能优化

### 1. 超时设置
```bash
# 设置 MCP 超时（毫秒）
export MCP_TIMEOUT=30000
```

### 2. 输出限制
```bash
# 限制 MCP 输出 token 数量
export MAX_MCP_OUTPUT_TOKENS=4000
```

### 3. 连接池
```bash
# 设置最大连接数
export MCP_MAX_CONNECTIONS=10
```

### 4. 缓存配置
```bash
# 启用响应缓存
export MCP_CACHE_ENABLED=true
export MCP_CACHE_TTL=300  # 5分钟
```

## 安全最佳实践

### 1. 认证管理
- 使用 OAuth 代替硬编码令牌
- 定期轮换 API 密钥
- 使用环境变量存储敏感信息

### 2. 权限控制
- 仅配置必要的 MCP 服务器
- 限制文件系统访问范围
- 使用只读权限 where possible

### 3. 网络安全
- 使用 HTTPS 连接
- 验证服务器证书
- 限制内部网络访问

### 4. 配置安全
- 不要提交包含敏感信息的配置文件
- 使用 `.gitignore` 排除敏感配置
- 定期审计 MCP 配置

## 企业级配置

### 托管配置
企业可以部署托管 MCP 配置：
- **`managed-mcp.json`**: 系统级固定配置
- **允许列表/拒绝列表**: 控制可用的 MCP 服务器

### 配置位置
- **macOS**: `/Library/Application Support/ClaudeCode/managed-mcp.json`
- **Linux/WSL**: `/etc/claude-code/managed-mcp.json`
- **Windows**: `C:\Program Files\ClaudeCode\managed-mcp.json`

### 企业策略
```json
{
  "allowedServers": [
    "github",
    "filesystem",
    "postgres"
  ],
  "blockedServers": [
    "untrusted-service"
  ],
  "policies": {
    "requireHttps": true,
    "maxServers": 10,
    "timeout": 30000
  }
}
```

## 使用示例

### 示例 1: 开发环境配置
```bash
# 配置开发工具
claude mcp add --transport http github --scope project https://api.githubcopilot.com/mcp/
claude mcp add --transport stdio filesystem --scope project -- npx -y @modelcontextprotocol/server-filesystem
claude mcp add --transport stdio postgres --scope project --env PGHOST=localhost -- npx -y @modelcontextprotocol/server-postgres
```

### 示例 2: 数据分析配置
```bash
# 配置数据分析工具
claude mcp add --transport http bigquery --scope local https://mcp.bigquery.dev
claude mcp add --transport http tableau --scope local https://mcp.tableau.com
claude mcp add --transport stdio csv --scope local -- npx -y @modelcontextprotocol/server-csv
```

### 示例 3: 项目管理配置
```bash
# 配置项目管理工具
claude mcp add --transport http jira --scope project https://mcp.atlassian.com/mcp
claude mcp add --transport http slack --scope project https://mcp.slack.com
claude mcp add --transport http calendar --scope project https://mcp.google.com/calendar
```

## 更新和维护

### 定期维护任务
1. **清理未使用的服务器**
   ```bash
   claude mcp list
   # 删除不再需要的服务器
   ```

2. **更新服务器版本**
   ```bash
   # 删除旧版本
   claude mcp remove <server-name>

   # 添加新版本
   claude mcp add --transport stdio <server-name> -- npx -y <server-package>@latest
   ```

3. **备份配置**
   ```bash
   # 备份用户配置
   cp ~/.claude.json ~/.claude.json.backup

   # 备份项目配置
   cp .mcp.json .mcp.json.backup
   ```

### 监控和日志
```bash
# 查看 MCP 日志
tail -f ~/.claude/logs/mcp.log

# 监控连接状态
claude mcp list --verbose

# 检查错误日志
grep -i error ~/.claude/logs/mcp.log
```

## 总结

MCP 是 Claude Code 的核心扩展机制，通过合理配置和管理 MCP 服务器，可以显著提升 Claude 的能力和效率。关键要点：

1. **合理选择作用域**: 根据使用场景选择 user/project/local
2. **安全配置**: 使用环境变量保护敏感信息
3. **定期维护**: 清理和更新 MCP 配置
4. **性能优化**: 合理设置超时和连接参数
5. **故障排查**: 掌握基本的调试和排查方法