# 作用域选择决策树

## 决策流程图

```
开始选择作用域
    │
    ├── 这个工具是团队共享的吗？
    │    ├── 是 → 选择 project 作用域
    │    └── 否 → 继续
    │
    ├── 这个工具是个人专用的吗？
    │    ├── 是 → 选择 user 作用域
    │    └── 否 → 继续
    │
    ├── 这个工具需要项目特定的配置吗？
    │    ├── 是 → 选择 local 作用域
    │    └── 否 → 返回重新评估
    │
    └── 根据具体场景选择
```

## 详细决策指南

### 1. project 作用域（项目配置）

**选择条件**：
- ✅ 工具需要团队共享
- ✅ 配置应该纳入版本控制
- ✅ 所有团队成员都需要访问
- ✅ 配置与项目紧密相关

**典型场景**：
- 团队开发工具（GitHub、Jira、Slack）
- 项目数据库访问（PostgreSQL、MySQL）
- 项目 API 集成
- 团队协作工具

**配置文件**：项目根目录的 `.mcp.json`
**生效范围**：当前项目
**是否共享**：是（通过版本控制）

**示例**：
```json
{
  "scope": "project",
  "servers": {
    "github": {
      "type": "http",
      "url": "https://api.githubcopilot.com/mcp/"
    },
    "postgres": {
      "type": "stdio",
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-postgres"]
    }
  }
}
```

### 2. user 作用域（用户全局配置）

**选择条件**：
- ✅ 工具是个人专用的
- ✅ 配置不应该共享
- ✅ 在所有项目中都需要
- ✅ 包含个人 API 密钥或令牌

**典型场景**：
- 个人开发工具
- 个人 API 服务
- 全局实用工具
- 包含敏感信息的配置

**配置文件**：`~/.claude.json`
**生效范围**：所有项目
**是否共享**：否（个人配置）

**示例**：
```json
{
  "scope": "user",
  "servers": {
    "weather": {
      "type": "http",
      "url": "https://api.weather.com/mcp"
    },
    "personal-api": {
      "type": "http",
      "url": "https://api.personal.com/mcp",
      "headers": {
        "Authorization": "Bearer ${PERSONAL_API_KEY}"
      }
    }
  }
}
```

### 3. local 作用域（本地配置）

**选择条件**：
- ✅ 工具需要项目特定的配置
- ✅ 配置不应该共享
- ✅ 仅对当前项目有效
- ✅ 包含项目特定的敏感信息

**典型场景**：
- 项目特定的 API 密钥
- 内部测试环境配置
- 临时调试工具
- 个人项目覆盖配置

**配置文件**：`~/.claude.json` 中的项目特定路径
**生效范围**：指定项目
**是否共享**：否（个人项目配置）

**示例**：
```json
{
  "scope": "local",
  "servers": {
    "staging-api": {
      "type": "http",
      "url": "https://staging.api.com/mcp",
      "headers": {
        "Authorization": "Bearer ${STAGING_API_KEY}"
      }
    },
    "debug-tool": {
      "type": "stdio",
      "command": "python",
      "args": ["debug_server.py"]
    }
  }
}
```

## 场景分析表

| 场景 | 推荐作用域 | 理由 | 配置文件位置 |
|------|-----------|------|-------------|
| 团队 GitHub 集成 | project | 团队共享，版本控制 | `.mcp.json` |
| 个人天气查询 | user | 个人使用，全局生效 | `~/.claude.json` |
| 项目数据库访问 | project | 团队共享，项目相关 | `.mcp.json` |
| 个人 API 密钥 | user | 敏感信息，个人专用 | `~/.claude.json` |
| 测试环境配置 | local | 项目特定，不共享 | `~/.claude.json` |
| 临时调试工具 | local | 临时使用，项目特定 | `~/.claude.json` |
| 团队 Jira 集成 | project | 团队协作，版本控制 | `.mcp.json` |
| 个人笔记工具 | user | 个人使用，全局生效 | `~/.claude.json` |
| 生产环境配置 | local | 敏感信息，项目特定 | `~/.claude.json` |

## 决策问题列表

回答以下问题帮助选择作用域：

### 问题 1：这个工具需要团队共享吗？
- **是** → 考虑 `project` 作用域
- **否** → 继续问题 2

### 问题 2：这个工具在所有项目中都需要吗？
- **是** → 考虑 `user` 作用域
- **否** → 继续问题 3

### 问题 3：这个工具需要项目特定的配置吗？
- **是** → 考虑 `local` 作用域
- **否** → 重新评估需求

### 问题 4：配置包含敏感信息吗？
- **是** → 优先考虑 `user` 或 `local` 作用域
- **否** → 可以考虑 `project` 作用域

### 问题 5：配置需要版本控制吗？
- **是** → 选择 `project` 作用域
- **否** → 选择 `user` 或 `local` 作用域

## 混合配置策略

### 策略 1：基础 + 覆盖
- **基础配置** (`project`): 团队共享的基础工具
- **个人覆盖** (`local`): 个人特定的配置覆盖

**示例**：
```json
// .mcp.json (project)
{
  "mcpServers": {
    "github": { "type": "http", "url": "https://api.github.com/mcp" },
    "jira": { "type": "http", "url": "https://mcp.atlassian.com/mcp" }
  }
}

// ~/.claude.json (local 覆盖)
{
  "projects": {
    "/current/project": {
      "mcpServers": {
        "github": {
          "type": "http",
          "url": "https://api.github.com/mcp",
          "headers": {
            "Authorization": "Bearer ${PERSONAL_GITHUB_TOKEN}"
          }
        }
      }
    }
  }
}
```

### 策略 2：分层配置
- **全局层** (`user`): 个人全局工具
- **项目层** (`project`): 团队项目工具
- **环境层** (`local`): 环境特定配置

### 策略 3：按功能分组
- **开发工具** → `project` 作用域
- **个人工具** → `user` 作用域
- **环境配置** → `local` 作用域

## 迁移和转换指南

### 从 user 迁移到 project
**场景**：个人工具变成团队工具

**步骤**：
1. 从 `~/.claude.json` 复制配置
2. 移除敏感信息（API 密钥等）
3. 将配置添加到 `.mcp.json`
4. 从 `~/.claude.json` 删除原配置
5. 更新团队文档

### 从 project 迁移到 local
**场景**：团队工具需要个人特定配置

**步骤**：
1. 从 `.mcp.json` 复制配置模板
2. 在 `~/.claude.json` 中添加 local 配置
3. 添加个人特定的参数
4. 保持 `.mcp.json` 中的基础配置

### 从 local 迁移到 user
**场景**：项目特定工具变成个人全局工具

**步骤**：
1. 从 `~/.claude.json` 的 local 配置复制
2. 添加到 `~/.claude.json` 的 user 配置
3. 从 local 配置中删除
4. 验证在所有项目中生效

## 常见错误和解决方案

### 错误 1：选择了错误的作用域
**症状**：配置不生效或影响范围错误

**解决方案**：
1. 使用决策树重新评估
2. 迁移到正确的作用域
3. 清理错误的配置

### 错误 2：配置冲突
**症状**：相同服务器在不同作用域有不同配置

**解决方案**：
1. 确定优先级（local > project > user）
2. 清理低优先级的配置
3. 使用明确的命名避免冲突

### 错误 3：敏感信息泄露
**症状**：API 密钥提交到版本控制

**解决方案**：
1. 立即撤销泄露的密钥
2. 将配置迁移到 user 或 local 作用域
3. 使用环境变量代替硬编码

### 错误 4：配置不生效
**症状**：配置保存但工具不可用

**解决方案**：
1. 检查配置文件路径
2. 验证 JSON 格式
3. 检查作用域是否正确
4. 重启 Claude Code（如果需要）

## 最佳实践总结

### 1. 明确作用域边界
- **project**: 团队共享，版本控制
- **user**: 个人专用，全局生效
- **local**: 项目特定，不共享

### 2. 安全第一
- 敏感信息使用 user 或 local 作用域
- 使用环境变量代替硬编码
- 定期审计配置安全性

### 3. 保持简洁
- 避免过度配置
- 定期清理不再使用的配置
- 使用有意义的服务器名称

### 4. 文档化
- 记录团队共享的 MCP 配置
- 说明环境变量要求
- 维护配置变更日志

### 5. 测试验证
- 新配置先在 local 作用域测试
- 验证配置生效
- 测试工具功能正常

通过遵循这个决策树和最佳实践，可以确保 MCP 配置既安全又高效，满足团队和个人的不同需求。